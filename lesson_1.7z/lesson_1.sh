ubuntu@ip-172-31-46-143:~$ sudo systemctl status mysql
● mysql.service - MySQL Community Server
     Loaded: loaded (/lib/systemd/system/mysql.service; enabled; vendor preset: enabled)
     Active: active (running) since Sat 2020-06-13 12:11:49 UTC; 1min 33s ago
   Main PID: 2507 (mysqld)
     Status: "Server is operational"
      Tasks: 38 (limit: 1145)
     Memory: 372.0M
     CGroup: /system.slice/mysql.service
             └─2507 /usr/sbin/mysqld

Jun 13 12:11:48 ip-172-31-46-143 systemd[1]: Starting MySQL Community Server...
Jun 13 12:11:49 ip-172-31-46-143 systemd[1]: Started MySQL Community Server.

ubuntu@ip-172-31-46-143:~$ mysql -V
mysql  Ver 8.0.19-0ubuntu5 for Linux on x86_64 ((Ubuntu))
ubuntu@ip-172-31-46-143:~$ mysqld -V
/usr/sbin/mysqld  Ver 8.0.19-0ubuntu5 for Linux on x86_64 ((Ubuntu))

ubuntu@ip-172-31-46-143:~$ sudo mysql
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 8
Server version: 8.0.19-0ubuntu5 (Ubuntu)

Copyright (c) 2000, 2020, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> SHOW DATABASES;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
4 rows in set (0.01 sec)

mysql> ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '1234';FLUSH PRIVILEGES;
Query OK, 0 rows affected (0.00 sec)

Query OK, 0 rows affected (0.01 sec)

mysql> EXIT
Bye

ubuntu@ip-172-31-46-143:~$ mysql -u root -p
Enter password:
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 9
Server version: 8.0.19-0ubuntu5 (Ubuntu)

Copyright (c) 2000, 2020, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> exit
Bye